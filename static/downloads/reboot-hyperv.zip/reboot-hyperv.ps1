<#
.SYNOPSIS
Use BCDEDIT to select menu entry that enables or disables Hyper-V
.DESCRIPTION
Uses the 'BCDEDIT /bootsequence' command to select the boot menu option
that enables (or disables) Hyper-V (via 'hypervisorlaunchtype' menu option).
.PARAMETER Enable
Selects the boot menu that enables Hyper-V
(i.e. first entry with 'hypervisorlaunchtype' set to 'Auto' or 'On')
.PARAMETER Disable
Selects the boot menu that disables Hyper-V
(i.e. first entry with 'hypervisorlaunchtype' set to 'Off')
.PARAMETER Clear
Clears the BootSequence (revert to default boot)
.PARAMETER Pause
Pause the output (useful when running this script from a Shortcut)
.PARAMETER Message
Uses Pop-up MessageBox to display results 
(not supported in Powershell Core)
#>

[CmdletBinding(DefaultParameterSetName='hyperv-on')]
param (
    [Parameter(ParameterSetName='hyperv-on',Position=0)]
    [Alias("Enabled","e","on","true")]
    [Switch]$Enable=$false,
    [Parameter(ParameterSetName='hyperv-off',Position=0)]
    [Alias("Disabled","d","off","false")]
    [Switch]$Disable=$false,
    [Parameter(ParameterSetName='boot-clear',Position=0)]
    [Alias("Cleared","c","default")]
    [Switch]$Clear=$false,
    [Alias("Paused","p")]
    [Switch]$Pause=$false,
    [Alias("m","Message")]
    [Switch]$MessageBox=$false
)

if ($PSVersionTable.PSEdition -eq 'Desktop') {
    Add-Type -AssemblyName PresentationFramework
} else {
    $MessageBox=$false
    Write-Host "WARNING: The -Message option is not supported in Powershell Core.`r`nOnly console output allowed." -ForegroundColor "Red"
}
$Global:msg_box_txt = ''
$Global:msg_box_icon = 'Information'
$script_name = ([io.fileinfo]$MyInvocation.MyCommand.Definition).BaseName
function Pause-Host {
    param(
        $Delay = 1
    )
    $counter = 0;
    While(!$host.UI.RawUI.KeyAvailable -and ($counter++ -lt $Delay)) {
        [Threading.Thread]::Sleep(1000)
    }
}

function Modify-Boot-Sequence {
    # Get array of OSLOADER GUIDs from BCDEDIT
    $GUID_Array = bcdedit /enum OSLOADER /v | Select-String '^identifier\s+' `
                    | % {$_ -replace '^identifier\s+'}
    # Find first GUID that has 'hypervisorlaunchtype' for 'Auto' (or 'On') and 'Off'
    $HyperV_Enable = $null
    $HyperV_Disable = $null
    $HyperV_Enable_Desc = $null
    $HyperV_Disable_Desc = $null
    ForEach ($guid In $GUID_Array) {
        $hvlt = $null
        $desc = $null
        $hvlt = bcdedit /enum "$guid" | ? {$_ -match 'hypervisorlaunchtype\s+'} `
                    | % {$_ -replace '^hypervisorlaunchtype\s+'}
        $desc = bcdedit /enum "$guid" | ? {$_ -match 'description\s+'} `
                    | % {$_ -replace '^description\s+'}
        if ($hvlt -match '^(Auto|On)') {
            if ([string]::IsNullOrEmpty($HyperV_Enable)) {
                $HyperV_Enable = $guid
                $HyperV_Enable_Desc = $desc
            }
        }
        elseif ($hvlt -match '^Off') {
            if ([string]::IsNullOrEmpty($HyperV_Disable)) {
                $HyperV_Disable = $guid
                $HyperV_Disable_Desc = $desc
            }
        }
    }

    # Check to make sure we have both 'Enable' and 'Disable' boot
    # menu options set up
    if ( (-not $HyperV_Enable) -and (-not $HyperV_Disable) ) {
        $tmpstr = "It looks like you have not enabled Hyper-V in`r`n Windows Features.`r`nYou need to turn on Hyper-V before this script can work!"
        $Global:msg_box_txt = "${msg_box_txt}`r`n${tmpstr}`r`n"
        $Global:msg_box_icon = 'Error'
        Write-Host "${tmpstr}" -ForegroundColor "Red"
        return
    }
    elseif (-not $HyperV_Enable) {
        $tmpstr = "You have not configured your system to enable/disable Hyper-V!`r`nYou need to add a boot menu entry (using BCDEDIT)`r`nthat sets 'hypervisorlaunchtype' to 'Auto'"
        $Global:msg_box_txt = "${msg_box_txt}`r`n${tmpstr}`r`n"
        $Global:msg_box_icon = 'Error'
        Write-Host "${tmpstr}" -ForegroundColor "Red"
        return
    }
    elseif (-not $HyperV_Disable) {
        $tmpstr = "You have not configured your system to enable/disable Hyper-V!`r`nYou need to add a boot menu entry (using BCDEDIT)`r`nthat sets 'hypervisorlaunchtype' to 'Off'"
        $Global:msg_box_txt = "${msg_box_txt}`r`n${tmpstr}`r`n"
        $Global:msg_box_icon = 'Error'
        Write-Host "${tmpstr}" -ForegroundColor "Red"
        return
    }

    # Clear BootSequence (to make sure we're doing what we expect in the next part)
    if ($Clear -or $Enable -or $Disable) {
        $tmpstr = "Clearing any existing BootSeqence entries..."
        $Global:msg_box_txt = "${msg_box_txt}${tmpstr}`r`n"
        Write-Host "${tmpstr}" -BackgroundColor "Black"
        if ($HyperV_Enable) { bcdedit /bootsequence "$HyperV_Enable" /remove > $null }
        if ($HyperV_Disable) { bcdedit /bootsequence "$HyperV_Disable" /remove > $null }
    } else {
        $tmpstr = "Provide '-Enable', '-Disable' or '-Clear' option on command line!"
        $Global:msg_box_txt = "${msg_box_txt}`r`n${tmpstr}`r`n"
        $Global:msg_box_icon = 'Warning'
        Write-Host "${tmpstr}" -ForegroundColor "Red" -BackgroundColor "Yellow"
        return
    }

    # Configure Next Boot Sequence based on command line option selection

    # If we're ENABLING Hyper-V...
    if ($Enable) {
        if ($HyperV_Enable) {
            $tmpstr = "BootSequence set to boot`r`n  '$HyperV_Enable_Desc'`r`n on next restart/reboot"
            $Global:msg_box_txt = "${msg_box_txt}`r`n${tmpstr}`r`n"
            Write-Host "${tmpstr}" -ForegroundColor "DarkGreen" -BackgroundColor "Black"
            bcdedit /bootsequence "$HyperV_Enable" /addfirst > $null
        } else {
            $tmpstr = "Cannot find Boot option with 'hypervisorlaunchtype' set to 'Auto'"
            $Global:msg_box_txt = "${msg_box_txt}`r`n${tmpstr}`r`n"
            $Global:msg_box_icon = 'Error'
            Write-Host "${tmpstr}" -ForegroundColor "Red"
            return
        }
    }
    # If we're DISABLING Hyper-V
    elseif ($Disable) {
        if ($HyperV_Disable) {
            $tmpstr = "BootSequence set to boot`r`n  '$HyperV_Disable_Desc'`r`n on next restart/reboot"
            $Global:msg_box_txt = "${msg_box_txt}`r`n${tmpstr}`r`n"
            Write-Host "${tmpstr}" -ForegroundColor "DarkGreen" -BackgroundColor "Black"
            bcdedit /bootsequence "$HyperV_Disable" /addfirst > $null
        } else {
            $tmpstr = "Cannot find Boot option with 'hypervisorlaunchtype' set to 'Off'"
            $Global:msg_box_txt = "${msg_box_txt}`r`n${tmpstr}`r`n"
            $Global:msg_box_icon = 'Error'
            Write-Host "${tmpstr}" -ForegroundColor "Red"
            return
        }  
    }
}

Modify-Boot-Sequence

if ($MessageBox) {
    if (! $Global:msg_box_txt) {
        $Global:msg_box_txt = "No message text was returned. Status unknown."
    }
    [System.Windows.MessageBox]::Show("${msg_box_txt}",${script_name},'OK',${msg_box_icon})
}
elseif ($Pause) { Pause-Host(8) }